# Snapshot Auto-Tagging Project

## 📌 Purpose
Automatically tag all snapshots (EBS, RDS, FSx, AWS Backup) created manually or via AWS Backup with:
- `Retention=90days`
- `DeleteOn=YYYY-MM-DD`

## 📁 Contents
- `template.yaml` — Deploys Lambda, EventBridge, IAM Role
- `cloudtrail-template.yaml` — Enables CloudTrail logging
- `lambda/index.py` — Python code for tagging logic

## 🧪 Deployment Steps

### Step 1: Deploy CloudTrail
```bash
aws cloudformation deploy \
  --template-file cloudtrail-template.yaml \
  --stack-name enable-cloudtrail-logs \
  --capabilities CAPABILITY_NAMED_IAM
```

### Step 2: Package & Upload Lambda Code
```bash
zip lambda-code.zip index.py
aws s3 cp lambda-code.zip s3://<your-bucket-name>/
```

### Step 3: Deploy Tagging Stack
Update `template.yaml` with your `S3Bucket` and `S3Key`, then deploy:
```bash
aws cloudformation deploy \
  --template-file template.yaml \
  --stack-name snapshot-auto-tagger \
  --capabilities CAPABILITY_NAMED_IAM
```

## ✅ Validation
Create a snapshot or backup and verify tags:
- `Retention=90days`
- `DeleteOn=<date>`